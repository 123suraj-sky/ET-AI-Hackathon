import { BrowserRouter, Routes, Route } from "react-router-dom";

import MainLayout from "../layouts/MainLayout";

import Dashboard from "../pages/Dashboard/Dashboard";
import Forecast from "../pages/Forecast/Forecast";
import SourceAnalysis from "../pages/SourceAnalysis/SourceAnalysis";
import Recommendations from "../pages/Recommendations/Recommendations";
import CitizenHealth from "../pages/CitizenHealth/CitizenHealth";
import Reports from "../pages/Reports/Reports";

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <MainLayout>
              <Dashboard />
            </MainLayout>
          }
        />

        <Route
          path="/forecast"
          element={
            <MainLayout>
              <Forecast />
            </MainLayout>
          }
        />

        <Route
          path="/source-analysis"
          element={
            <MainLayout>
              <SourceAnalysis />
            </MainLayout>
          }
        />

        <Route
          path="/recommendations"
          element={
            <MainLayout>
              <Recommendations />
            </MainLayout>
          }
        />

        <Route
          path="/citizen-health"
          element={
            <MainLayout>
              <CitizenHealth />
            </MainLayout>
          }
        />

        <Route
          path="/reports"
          element={
            <MainLayout>
              <Reports />
            </MainLayout>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;