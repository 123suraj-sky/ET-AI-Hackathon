import "./Navbar.css";
import { FaBell, FaUserCircle } from "react-icons/fa";

function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <h2>🌍 AirVision</h2>
      </div>

      <div className="search">
        <input type="text" placeholder="Search City..." />
      </div>

      <div className="nav-icons">
        <FaBell className="icon" />
        <FaUserCircle className="icon" />
      </div>
    </nav>
  );
}

export default Navbar;